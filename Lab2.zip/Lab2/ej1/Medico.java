import java.util.ArrayList;

public class Medico {

    private String medico;
    private ArrayList<Paciente> paciente = new ArrayList<Paciente>();


    public Medico(String nombre_medico) {
        this.medico = medico;
    }

    //getter
    void mostrarPacientesdelMedico(){
        for (Paciente paciente: paciente){
            System.out.println(paciente.getName() + ": " + paciente.getMass()+ " kg, "+ paciente.getHigh()+" cm, "+paciente.getBMI()+" , "+paciente.getBlood());

        }
    }

    public String getMedico() {
        return medico;
    }
    //setter

    void pacientes(Paciente persona)
    {
        paciente.add(persona);
    }

    public void setMedico(String medico) {
        this.medico = medico;
    }
}
