import java.util.ArrayList;


public class Paciente {

    private String Name;
    private int mass;
    private int high;
    private double BMI;
    private String blood;
    private ArrayList<Medico> medico = new ArrayList<Medico>();


    public Paciente(String nombre, int masa, int altura, double IMC, String sangre, String medico) {
       Name = nombre;
       mass = masa;
       high = altura;
       BMI = IMC;
       blood = sangre;
       medico= medico;
    }


    //gettter nombre, masa, altura, IMC, sangre y medico que lo atiende

    public String getName() {
        return Name;
    }

    public int getMass() {
        return mass;
    }

    public int getHigh() {
        return high;
    }

    public double getBMI() {
        return BMI;
    }

    public String getBlood() {
        return blood;
    }


    void mostrarMedicosdelPaciente(){
        for (Medico medico: medico){
            System.out.println(medico.getMedico());

        }
    }

    //setter nombre, masa, altura, IMC, sangre y medico que lo atiende

    public void setName(String name) {
        Name = name;
    }

    public void setMass(int mass) {
        this.mass = mass;
    }

    public void setHigh(int high) {
        this.high = high;
    }

    public void setBMI(double BMI) {
        this.BMI = BMI;
    }

    public void setBlood(String blood) {
        this.blood = blood;
    }

    void medico(Medico personal)
    {
        medico.add(personal);
    }
}
