public class Main {


    public static void main(String[] args){

    Paciente p;
    Medico m;

    p = new Paciente("Pepito", 55, 150, 24.44, "A2+", "Leon");
    m =  new Medico("Leon");


    System.out.println(p.getName() + ": \n \t Masa: " + p.getMass()+ "kg\n\t Altura: "+ p.getHigh()+"cm\n\t IMC: "+p.getBMI()+" \n\t Sangre: "+p.getBlood());


    }

}
