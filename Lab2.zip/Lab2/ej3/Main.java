import java.util.Random;
import java.util.Scanner;


public class Main {

    public static void main(String[] args){

        Termometro t1, t2;
        double temperatura1, temperatura2;
        Scanner scanner;
        int veces = 0;
        double prom;

        temperatura1= new Random().nextDouble()*6+35;
        temperatura2= new Random().nextDouble()*6+35;
        t1 = new Termometro(temperatura1);
        t1.setTemperatura(temperatura1);
        t2 = new Termometro(temperatura2);
        t2.setTemperatura(temperatura2);

        prom = (temperatura1+temperatura2)/2;


        System.out.println("Para agitar el termometro presione A: ");
        scanner = new Scanner(System.in);
        String preguntar = scanner.nextLine();


        while (!"A".equals(preguntar)){
            System.out.println("Presione A (Mayuscula): ");
            preguntar=scanner.nextLine();
        }
        if ("A".equals(preguntar)){
            if (veces < 3){


                System.out.println(t1.getTemperatura()+"ºC \n¿Desea agitar nuevamente? (Presione A):");
                preguntar=scanner.nextLine();

                while (!"A".equals(preguntar)) {
                    System.out.println("Presione A (Mayuscula): ");
                    preguntar = scanner.nextLine();
                }
                veces=veces+1;
                System.out.println(t2.getTemperatura()+"ºC" );
                System.out.println("el promedio de ambas temperaturas es:" + prom);


            }


        }




    }

}
