

public class Termometro {

    private double temperature;


    public Termometro(double temperatura) {
        this.temperature = temperatura;
    }

    public double getTemperatura() {
        return temperature;
    }

    public void setTemperatura(double temperatura) {
        this.temperature = temperatura;
    }
}
